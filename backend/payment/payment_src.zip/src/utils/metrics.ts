import { Request, Response } from "express";
import client from "prom-client";

const register = new client.Registry();
client.collectDefaultMetrics({ prefix: "payment_service_", register });

export const requestDurationHistogram = new client.Histogram({
  name:       "payment_http_request_duration_seconds",
  help:       "Payment service HTTP request duration in seconds",
  buckets:    [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5],
  labelNames: ["method", "route", "status_code", "success"],
  registers:  [register],
});

export const httpRequestCounter = new client.Counter({
  name:       "payment_http_request_total",
  help:       "Total HTTP requests handled by payment service",
  labelNames: ["method", "route", "status_code", "success"],
  registers:  [register],
});

export const errorCounter = new client.Counter({
  name:       "payment_service_errors_total",
  help:       "Total errors in payment service",
  labelNames: ["error_type", "operation", "severity"],
  registers:  [register],
});

export const serverHealthGauge = new client.Gauge({
  name:      "payment_service_health_status",
  help:      "Payment service health: 1=healthy 0=unhealthy",
  registers: [register],
});

export const webhookProcessedCounter = new client.Counter({
  name:       "payment_webhooks_processed_total",
  help:       "Total webhooks processed",
  labelNames: ["gateway", "status"],
  registers:  [register],
});

export const outboxProcessedCounter = new client.Counter({
  name:       "payment_outbox_events_processed_total",
  help:       "Total outbox events processed",
  labelNames: ["event_type", "status"],
  registers:  [register],
});

export const circuitBreakerCounter = new client.Counter({
  name:       "gateway_circuit_breaker_events_total",
  help:       "Total circuit breaker state change and request events",
  labelNames: ["service", "event"],
  registers:  [register],
});

export const circuitBreakerStateGauge = new client.Gauge({
  name:       "gateway_circuit_breaker_state",
  help:       "Circuit breaker state: 0=closed 1=halfOpen 2=open",
  labelNames: ["service"],
  registers:  [register],
});

export function trackError(
  errorType: string,
  operation: string,
  severity:  "low" | "medium" | "high" | "critical" = "medium"
): void {
  errorCounter.inc({ error_type: errorType, operation, severity });
}

export function trackCircuitBreakerEvent(
  service: string,
  event:   "open" | "halfOpen" | "close" | "failure" | "success" | "timeout" | "reject"
): void {
  circuitBreakerCounter.inc({ service, event });

  if (event === "open")     circuitBreakerStateGauge.set({ service }, 2);
  if (event === "halfOpen") circuitBreakerStateGauge.set({ service }, 1);
  if (event === "close")    circuitBreakerStateGauge.set({ service }, 0);
}

export function reqReplyTime(
  req:       Request,
  res:       Response,
  startTime: [number, number]
): void {
  const [s, ns] = process.hrtime(startTime);
  const duration = s + ns / 1e9;
  const success  = res.statusCode < 400 ? "true" : "false";
  const labels   = {
    method:      req.method,
    route:       req.route?.path ?? req.url,
    status_code: String(res.statusCode),
    success,
  };
  requestDurationHistogram.observe(labels, duration);
  httpRequestCounter.inc(labels);
}

export const paymentRegistry = register;